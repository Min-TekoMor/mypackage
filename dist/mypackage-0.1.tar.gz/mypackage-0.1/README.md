#mypackage
This library was created as an exercise for creating your own package at EDSA.

How to Install
...